from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from song.models import SongPost
from . import models


# 文章评论
@login_required(login_url='/userprofile/login/')
def post_comment(request, song_id):
    song = get_object_or_404(SongPost, id=song_id)
    if request.method == 'POST':
        new_comment_body = request.POST.get('body')
        new_song_user = request.user
        models.Comment.objects.create(song=song, body=new_comment_body,user=new_song_user)
        return redirect(song)
    else:
        return HttpResponse("发表评论仅接受POST请求。")