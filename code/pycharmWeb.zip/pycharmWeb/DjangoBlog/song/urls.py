# 引入path
from django.conf.urls import url
from django.urls import path
# 引入views.py
from . import views

# 正在部署的应用的名称
app_name = 'song'

urlpatterns = [
    url(r'^$', views.song_list),
    # path函数将url映射到视图
    path('song-list/', views.song_list, name='song_list'),
    # 文章详情
    path('song-detail/<int:id>/', views.song_detail, name='song_detail'),
    # 写文章
    path('song-create/', views.song_create, name='song_create'),
    # 删除文章
    path('song-delete/<int:id>/', views.song_delete, name='song_delete'),
    # 更新文章
    path('song-update/<int:id>/', views.song_update, name='song_update'),
]