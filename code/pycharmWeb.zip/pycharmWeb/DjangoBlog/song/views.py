from django.shortcuts import render

# Create your views here.
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.shortcuts import render,redirect
# 导入数据模型ArticlePost
from comment.models import Comment
from . import models
from .models import SongPost
# 引入User模型
from django.contrib.auth.models import User
# 引入分页模块
from django.core.paginator import Paginator

def song_list(request):
    # 根据GET请求中查询条件
    # 返回不同排序的对象数组
    if request.GET.get('order') == 'total_views':
        song_list = SongPost.objects.all().order_by('-total_views')
        order = 'total_views'
    else:
        song_list = SongPost.objects.all()
        order = 'normal'

    paginator = Paginator(song_list, 4)
    page = request.GET.get('page')
    songs = paginator.get_page(page)

    # 修改此行
    context = { 'songs': songs, 'order': order }

    return render(request, 'song/list.html', context)

def song_create(request):
    if request.method == 'POST':
        new_song_title = request.POST.get('title')
        new_song_body = request.POST.get('body')
        new_song_author = User.objects.get(id=1)
        models.SongPost.objects.create(title=new_song_title, body=new_song_body,author=new_song_author)
        return redirect("song:song_list")
    # 如果用户请求获取数据
    else:
        return render(request, 'song/create.html')

# 文章详情
def song_detail(request, id):
    # 取出相应的文章
    song = SongPost.objects.get(id=id)
    # 浏览量 +1
    song.total_views += 1
    song.save(update_fields=['total_views'])

    # 取出文章评论
    comments = Comment.objects.filter(article=id)

    # 需要传递给模板的对象
    # context = { 'article': article }
    context = { 'song': song, 'comments': comments }
    # 载入模板，并返回context对象
    return render(request, 'song/detail.html', context)

# 删文章
def song_delete(request, id):
    # 根据 id 获取需要删除的文章
    song = SongPost.objects.get(id=id)
    # 调用.delete()方法删除文章
    song.delete()
    # 完成删除后返回文章列表
    return redirect("song:song_list")

# 更新文章
# 提醒用户登录
@login_required(login_url='/userprofile/login/')

def song_update(request, id):
    # # 获取需要修改的具体文章对象
    song = SongPost.objects.get(id=id)
    # 过滤非作者的用户
    if request.user != song.author:
        return HttpResponse("抱歉，你无权修改这首戏曲。")

    # 判断用户是否为 POST 提交表单数据
    if request.method == "POST":
        new_song_title = request.POST.get('title')
        new_song_body = request.POST.get('body')
        song.title = new_song_title
        song.body = new_song_body
        song.save()
        # 完成后返回到修改后的文章中。需传入文章的 id 值
        return redirect("song:song_detail", id=id)
    else:
        # 赋值上下文，将 article 文章对象也传递进去，以便提取旧的内容
        context = {'song': song}
        return render(request, 'song/update.html', context)
