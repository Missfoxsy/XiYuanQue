from django.shortcuts import render, redirect
from apphot import models
from django.core.paginator import Paginator
from django.http import JsonResponse, HttpResponse
import random
import time
import json

# Create your views here.

# 01 戏曲信息列表
def search(request):
    q = request.GET.get('q')
    error_msg = ''

    if not q:
        error_msg = '请输入关键词'
        return render(request, 'result.html', {'error_msg': error_msg})

    data_list=models.Info_xq.objects.filter(xqname__contains=q)
    return render(request, 'result.html', {'error_msg': error_msg, 'post_list': data_list})


def data_xq(request, pindex):
    '''分页'''
    areas = models.Info_xq.objects.all()  # ar = models.Info_hot.objects.values('hot_word')
    # 创建Paginator对象，进行分页，每页显示10条
    paginator = Paginator(areas, 10)
    # 总条数：也就是data_hot元素的个数，31
    p_count = paginator.count
    # 总页数：book_list有7个元素，每页显示3个，那么会被分成3页
    a_count = paginator.num_pages

    if pindex == '':
        pindex = 1
    else:
        pindex = int(pindex)
    # 获取第一页的内容，page时Page类的实例对象
    page = paginator.page(pindex)

    # 当页数过多时，进行缩减处理
    if pindex-5 < 1:
        pageRange = range(1, 11)
    elif pindex+5 > paginator.num_pages:
        pageRange = range(pindex-5, paginator.num_pages+1)
    else:
        pageRange = range(pindex-5, pindex+5)
    return render(request, 'hot/hot_page.html', locals())

