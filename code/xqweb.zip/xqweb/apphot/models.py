from django.db import models

# Create your models here.

# ssq的类
class Info_xq(models.Model):
    xqtype = models.CharField('类型', max_length=45)
    xqname = models.CharField('名称', max_length=45)
    xqgc = models.CharField('歌词', max_length=2000)

