-- MySQL dump 10.13  Distrib 5.6.37, for Win64 (x86_64)
--
-- Host: localhost    Database: chineseopera
-- ------------------------------------------------------
-- Server version	5.6.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artist`
--

DROP TABLE IF EXISTS `artist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `artist` (
  `ArtistID` varchar(10) NOT NULL DEFAULT '',
  `name` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`ArtistID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist`
--

LOCK TABLES `artist` WRITE;
/*!40000 ALTER TABLE `artist` DISABLE KEYS */;
/*!40000 ALTER TABLE `artist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `creation`
--

DROP TABLE IF EXISTS `creation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creation` (
  `MusicID` varchar(15) NOT NULL DEFAULT '',
  `ArtistID` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`MusicID`,`ArtistID`),
  KEY `ArtistID` (`ArtistID`),
  CONSTRAINT `creation_ibfk_1` FOREIGN KEY (`MusicID`) REFERENCES `musiclibrary` (`MusicID`),
  CONSTRAINT `creation_ibfk_2` FOREIGN KEY (`ArtistID`) REFERENCES `artist` (`ArtistID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `creation`
--

LOCK TABLES `creation` WRITE;
/*!40000 ALTER TABLE `creation` DISABLE KEYS */;
/*!40000 ALTER TABLE `creation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `musiclibrary`
--

DROP TABLE IF EXISTS `musiclibrary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `musiclibrary` (
  `MusicID` varchar(15) NOT NULL DEFAULT '',
  `title` varchar(20) NOT NULL,
  `type` char(6) NOT NULL,
  `lyrics` text,
  `link` tinytext,
  PRIMARY KEY (`MusicID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `musiclibrary`
--

LOCK TABLES `musiclibrary` WRITE;
/*!40000 ALTER TABLE `musiclibrary` DISABLE KEYS */;
INSERT INTO `musiclibrary` VALUES ('000000000000000','01.马鞍山（01）','京剧','【二黄原板】\n我二人在山前金兰义好\n钟贤弟他不来所为那条\n莫不是在家中奉养二老\n因此上与朋友失信在今朝\n叫童儿你与我向前引道\n去到那集贤村访问故交\n','https://c6.y.qq.com/base/fcgi-bin/u?__=8b4UZ8J6WlAx'),('000000000000001','01.马鞍山（02）','京剧','【二黄三眼】\n想去岁中秋节相逢甚巧\n在月下调琴律得遇知交\n结金兰忘贵贱皆因同调\n赠黄金好一似管鲍相交','https://c6.y.qq.com/base/fcgi-bin/u?__=yYCKRcZ6Wd8g');
/*!40000 ALTER TABLE `musiclibrary` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-12 14:35:39
